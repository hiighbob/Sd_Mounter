#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
MODDIR=${0%/*}

# Auto-reparation exFAT si HiddenMount detecte
ST=$(sm list-volumes all | grep "6603-7A19" | awk '{print $2}')
if [ "$ST" = "HiddenMount" ] || [ "$ST" = "unmounted" ]; then
    echo "[AUTO-REPAIR] Detection HiddenMount, lancement fix_exfat..." >> "$MODDIR/logs/service.log"
    sh "$MODDIR/scripts/fix_exfat.sh"
    sh "$MODDIR/scripts/recover_grayed.sh" --silent
fi
