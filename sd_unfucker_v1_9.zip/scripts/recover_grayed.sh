#!/system/bin/sh
# Signal broadcast pour revivre les apps grisées sur Samsung
am broadcast -a android.intent.action.MEDIA_MOUNTED --receiver-foreground -d "file:///storage/6603-7A19"
sleep 2
pm scan /storage/6603-7A19
