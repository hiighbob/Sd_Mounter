#!/system/bin/sh
MODDIR=${0%/*}/..
LOG="$MODDIR/logs/fix_exfat.log"
EXFAT_UUID="6603-7A19"

echo "[$(date '+%F %T')] fix_exfat v1.9 START" >> "$LOG"
# Forcer le demontage vold pour liberer le verrou
VOLID=$(sm list-volumes all | grep "$EXFAT_UUID" | awk '{print $1}')
sm unmount "$VOLID" >> "$LOG" 2>&1

# Reparation
fsck.exfat -p /dev/block/mmcblk1p1 >> "$LOG" 2>&1
sleep 2

# Remontage
sm mount "$VOLID" >> "$LOG" 2>&1
