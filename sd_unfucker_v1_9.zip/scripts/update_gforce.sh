#!/system/bin/sh
# Script pour verifier les nouvelles versions sur le Drive/Repo
echo "[MAJ] Recherche de mises a jour pour SD-Unfucker..."
# Logique de check version ici
