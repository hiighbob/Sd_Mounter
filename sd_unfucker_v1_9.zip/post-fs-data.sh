#!/system/bin/sh
MODDIR=${0%/*}
LOG="$MODDIR/logs/post-fs-data.log"
CONF="$MODDIR/bind_mounts.conf"
mkdir -p "$MODDIR/logs"

echo "[$(date '+%F %T')] post-fs-data START v1.9" >> "$LOG"

# Correction critique: Attente du controleur MMC pour eviter "p2 absente"
for i in 1 2 3 4 5; do
    [ -b /dev/block/mmcblk1p2 ] && break
    echo "[$(date '+%F %T')] attente mmcblk1p2 ($i/5)..." >> "$LOG"
    sleep 1
done

EXT4_MNT=$(grep "^/dev/block/mmcblk1p2 " /proc/mounts | awk '{print $2}' | head -1)
if [ -z "$EXT4_MNT" ]; then
    echo "[$(date '+%F %T')] mmcblk1p2 toujours absente - report au service.sh" >> "$LOG"
    exit 0
fi

# Fix Termux: Remount EXEC
mount -o remount,exec,suid,dev "$EXT4_MNT"
echo "[$(date '+%F %T')] ext4 remount exec exit=$?" >> "$LOG"
echo "$EXT4_MNT" > "$MODDIR/ext4_mountpoint.txt"

# Rejouer les binds
if [ -f "$CONF" ]; then
    while IFS= read -r line; do
        [ -z "$line" ] || [ "${line###}" != "$line" ] && continue
        SRC=$(echo "$line" | awk '{print $4}')
        DST=$(echo "$line" | awk '{print $3}')
        if [ -d "$SRC" ] && [ -d "$DST" ] && ! mountpoint -q "$SRC"; then
            mount --bind "$DST" "$SRC"
            echo "[$(date '+%F %T')] bind: $SRC -> $DST" >> "$LOG"
        fi
    done < "$CONF"
fi
