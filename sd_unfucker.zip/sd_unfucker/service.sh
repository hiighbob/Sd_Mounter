#!/system/bin/sh
# service.sh — SD-Unfucker v1.8
MODDIR=${0%/*}
LOG="$MODDIR/logs/service.log"
STATUS="$MODDIR/webroot/status.json"
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT_FILE="$MODDIR/ext4_mountpoint.txt"
EXFAT_UUID="6603-7A19"
EXFAT_MNT="/storage/$EXFAT_UUID"
MMC_POWER="/sys/class/mmc_host/mmc1/power/control"
MMC_DELAY="/sys/class/mmc_host/mmc1/power/autosuspend_delay_ms"

mkdir -p "$MODDIR/logs"
echo "" >> "$LOG"
echo "========================================" >> "$LOG"
echo "[$(date '+%F %T')] service START v1.8" >> "$LOG"

log()    { echo "[$(date '+%F %T')] $1" >> "$LOG"; }
log_ec() { echo "[$(date '+%F %T')]   exit=$1" >> "$LOG"; }

get_exfat_state() { sm list-volumes all 2>/dev/null | grep "$EXFAT_UUID" | awk '{print $2}'; }
get_exfat_volid() { sm list-volumes all 2>/dev/null | grep "$EXFAT_UUID" | awk '{print $1}'; }

_broadcast_mounted() {
    am broadcast -a android.intent.action.MEDIA_MOUNTED \
        --receiver-foreground --include-stopped-packages \
        -d "file://$EXFAT_MNT" >> "$LOG" 2>&1
}

_hotplug_simulate() {
    if [ -w "$MMC_POWER" ]; then
        [ -w "$MMC_DELAY" ] && echo 0 > "$MMC_DELAY" 2>/dev/null
        echo auto > "$MMC_POWER" 2>/dev/null
        sleep 3
        echo on > "$MMC_POWER" 2>/dev/null
        sleep 5
        HWAIT=0
        while [ $HWAIT -lt 15 ]; do
            ST=$(get_exfat_state)
            echo "$ST" | grep -qiE "^mounted$|^checking$|^unmounted$" && break
            sleep 3; HWAIT=$((HWAIT+3))
        done
    else
        setprop ctl.restart vold >> "$LOG" 2>&1
        sleep 10
    fi
}

fix_exfat() {
    # FIX #1: EXFAT_VOLID re-fetché localement — évite variable vide
    EXFAT_VOLID=$(get_exfat_volid)
    [ -z "$EXFAT_VOLID" ] && EXFAT_VOLID="public:179,33"
    log "=== fix_exfat START (vol-id: $EXFAT_VOLID) ==="

    if mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
        umount -l "$EXFAT_MNT" >> "$LOG" 2>&1; log_ec $?
        sleep 2
    fi

    for fsck in /system/bin/fsck.exfat /system/xbin/fsck.exfat /sbin/fsck.exfat; do
        [ -x "$fsck" ] && { "$fsck" -p /dev/block/mmcblk1p1 >> "$LOG" 2>&1; log_ec $?; sleep 2; break; }
    done

    log "sm mount $EXFAT_VOLID"
    sm mount "$EXFAT_VOLID" >> "$LOG" 2>&1; log_ec $?
    sleep 4
    EXFAT_STATE=$(get_exfat_state)
    if echo "$EXFAT_STATE" | grep -qi "^mounted$"; then
        _broadcast_mounted
        sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
        log "fix_exfat END OK"; return 0
    fi

    ALT_VOLID=$(get_exfat_volid)
    if [ -n "$ALT_VOLID" ] && [ "$ALT_VOLID" != "$EXFAT_VOLID" ]; then
        sm mount "$ALT_VOLID" >> "$LOG" 2>&1; log_ec $?
        sleep 4
        if echo "$(get_exfat_state)" | grep -qi "^mounted$"; then
            _broadcast_mounted
            sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
            log "fix_exfat END OK (alt)"; return 0
        fi
    fi

    mkdir -p "$EXFAT_MNT"
    OPTS="uid=1023,gid=1023,fmask=0007,dmask=0007,allow_utime=0022,utf8,quiet,errors=remount-ro"
    mount -t sdfat /dev/block/mmcblk1p1 "$EXFAT_MNT" -o "$OPTS" >> "$LOG" 2>&1; log_ec $?
    if ! mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
        mount -t exfat /dev/block/mmcblk1p1 "$EXFAT_MNT" -o "$OPTS" >> "$LOG" 2>&1; log_ec $?
    fi
    if mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
        _broadcast_mounted
        sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
        log "fix_exfat END OK (direct)"; return 0
    fi

    _hotplug_simulate
    sleep 8
    EXFAT_VOLID=$(get_exfat_volid)
    [ -z "$EXFAT_VOLID" ] && EXFAT_VOLID="public:179,33"
    sm mount "$EXFAT_VOLID" >> "$LOG" 2>&1; log_ec $?
    if echo "$(get_exfat_state)" | grep -qi "^mounted$"; then
        _broadcast_mounted
        sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
    fi
    log "fix_exfat END"
}

guard_binds() {
    [ ! -f "$CONF" ] && return
    EXT4_MNT="/data/sdext2"
    [ -f "$EXT4_MNT_FILE" ] && EXT4_MNT=$(cat "$EXT4_MNT_FILE" | tr -d '[:space:]')
    if ! mountpoint -q "$EXT4_MNT" 2>/dev/null; then
        ALT=$(grep "^/dev/block/mmcblk1p2 " /proc/mounts 2>/dev/null \
            | awk '{print $2}' | grep -v "^/data/app\|^/data/data" | head -1)
        [ -n "$ALT" ] && EXT4_MNT="$ALT" || return
    fi
    mount -o remount,exec,suid,dev "$EXT4_MNT" 2>/dev/null
    OK=0; ALREADY=0; SKIP=0
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        case "$line" in '#'*) continue ;; esac
        SRC=$(echo "$line" | awk '{print $3}')
        DST=$(echo "$line" | awk '{print $4}')
        # FIX #2: deux conditions séparées
        [ -z "$SRC" ] && continue
        [ -z "$DST" ] && continue
        if [ -d "$SRC" ] && [ -d "$DST" ]; then
            if mountpoint -q "$DST" 2>/dev/null; then
                ALREADY=$((ALREADY+1))
            else
                mount --bind "$SRC" "$DST" >> "$LOG" 2>&1
                EC=$?; log_ec $EC
                [ $EC -eq 0 ] && OK=$((OK+1)) || SKIP=$((SKIP+1))
            fi
        else
            SKIP=$((SKIP+1))
        fi
    done < "$CONF"
    log "guard_binds: rebindés=$OK déjàOK=$ALREADY skip=$SKIP"
}

fix_termux_permissions() {
    TERMUX_TARGET="/data/data/com.termux/files"
    if [ -d "$TERMUX_TARGET" ]; then
        TERMUX_UID=$(stat -c "%u" /data/data/com.termux 2>/dev/null)
        if [ -n "$TERMUX_UID" ] && [ "$TERMUX_UID" != "root" ] && [ "$TERMUX_UID" != "0" ]; then
            chown -R "$TERMUX_UID:$TERMUX_UID" "$TERMUX_TARGET"
            chcon -R u:object_r:app_data_file:s0 "$TERMUX_TARGET"
            chmod -R 700 "$TERMUX_TARGET"
            log "fix_termux: chown $TERMUX_UID OK"
        fi
    fi
}

_packagewatcher_daemon() {
    EXT4_MNT="/data/sdext2"
    [ -f "$EXT4_MNT_FILE" ] && EXT4_MNT=$(cat "$EXT4_MNT_FILE" | tr -d '[:space:]')
    logcat -b system -s PackageManager:* *:S | while IFS= read -r line; do
        echo "$line" | grep -qE "New package installed|Package.*code path" || continue
        pkg=$(echo "$line" | grep -oE '[a-z][a-z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+' | head -1)
        [ -z "$pkg" ] && continue
        echo "$pkg" | grep -qE '^(android|com\.android|com\.samsung|com\.google\.android)' && continue
        grep -q "/data/data/$pkg$" "$CONF" && continue

        sleep 2
        am force-stop "$pkg" 2>/dev/null

        if [ -d "/data/data/$pkg" ]; then
            mkdir -p "$EXT4_MNT/data/$pkg"
            uid=$(stat -c %u "/data/data/$pkg")
            cp -a "/data/data/$pkg/." "$EXT4_MNT/data/$pkg/"
            chown -R "$uid":"$uid" "$EXT4_MNT/data/$pkg"
            rm -rf "/data/data/$pkg" && mkdir -p "/data/data/$pkg"
            mount --bind "$EXT4_MNT/data/$pkg" "/data/data/$pkg"
            chcon -R u:object_r:app_data_file:s0 "/data/data/$pkg"
            echo "mount --bind $EXT4_MNT/data/$pkg /data/data/$pkg" >> "$CONF"
        fi

        # FIX #3: glob APK via ls + test -n, pas [ -d glob ]
        APK_SRC=$(ls -d "/data/app/${pkg}"-* 2>/dev/null | head -1)
        if [ -n "$APK_SRC" ] && [ -d "$APK_SRC" ]; then
            APK_NAME=$(basename "$APK_SRC")
            mkdir -p "$EXT4_MNT/app/$APK_NAME"
            cp -a "$APK_SRC/." "$EXT4_MNT/app/$APK_NAME/"
            rm -rf "$APK_SRC" && mkdir -p "$APK_SRC"
            mount --bind "$EXT4_MNT/app/$APK_NAME" "$APK_SRC"
            chcon u:object_r:apk_data_file:s0 "$APK_SRC"
            echo "mount --bind $EXT4_MNT/app/$APK_NAME $APK_SRC" >> "$CONF"
        fi
        sh "$MODDIR/scripts/status.sh" > "$MODDIR/webroot/status.json" 2>/dev/null
    done
}

# -- MAIN EXECUTION --
WAITED=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    sleep 5; WAITED=$((WAITED+5))
    [ $WAITED -ge 150 ] && break
done
sleep 8

log "MBR guard: vérification byte 450..."
BYTE450=$(dd if=/dev/block/mmcblk1 bs=1 skip=450 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
log "  byte 450 = 0x$BYTE450"
if [ "$BYTE450" != "07" ]; then
    printf '\x07' | dd of=/dev/block/mmcblk1 bs=1 seek=450 count=1 conv=notrunc >> "$LOG" 2>&1
    log_ec $?
fi

EXFAT_STATE=$(get_exfat_state)
EXFAT_VOLID=$(get_exfat_volid)
[ -z "$EXFAT_VOLID" ] && EXFAT_VOLID="public:179,33"

case "$EXFAT_STATE" in
    mounted)    sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1 ;;
    ejecting|formatting) ;;
    "")         sleep 15; fix_exfat ;;
    *)          fix_exfat ;;
esac

guard_binds
fix_termux_permissions
sh "$MODDIR/scripts/status.sh" > "$STATUS" 2>/dev/null

_packagewatcher_daemon &

log "service END v1.8"
