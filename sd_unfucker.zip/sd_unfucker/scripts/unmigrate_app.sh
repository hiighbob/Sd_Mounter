#!/system/bin/sh
# =============================================================================
# unmigrate_app.sh — SD-Unfucker & Migrator v1.4
# =============================================================================
#
# RÔLE : Annuler une migration — resync données ext4 → interne, démonter
#   le bind mount, retirer l'entrée de bind_mounts.conf.
#
# NOUVEAUTÉ v1.4 — RESYNC AVANT UMOUNT (correction bug critique v1.1-v1.3) :
#   Avant de démonter, on resynchronise les données écrites sur ext4 depuis
#   la migration vers le stockage interne. Cela évite la perte de données.
#
# SÉQUENCE :
#   1. Vérification que le package est bien migré
#   2. Force-stop de l'app
#   3. Calcul de l'espace requis pour le resync (ext4 → interne)
#   4. Si espace insuffisant → ABORT avec message clair (pas de perte silencieuse)
#   5. Resync : rsync-style via tar pipe (ext4/dst → interne/src)
#   6. umount du bind mount
#   7. Retrait de bind_mounts.conf
#
# POURQUOI TAR ET PAS CP -A :
#   Le répertoire interne SRC (/data/data/<pkg>) contient déjà les fichiers
#   pré-migration (l'ancienne version). cp -a ne supprime pas les fichiers
#   obsolètes. tar pipe avec extraction écrase proprement les fichiers existants.
#   Note : on n'efface pas les données ext4 (sécurité — récupération manuelle possible).
#
# USAGE :
#   sh unmigrate_app.sh <package_name>
#   sh unmigrate_app.sh <package_name> --force  → skip resync (RISQUE perte données)
#
# CODES RETOUR :
#   0 → succès
#   1 → erreur (bind non démonté, package non dans conf)
#   2 → espace insuffisant (aborted — données préservées)
#
# DEVICE : SM-A530W · Android 9
# APPELÉ : WebUI (runUnmigrate()), ligne de commande
# =============================================================================

PKG="$1"
FORCE=0
[ "$2" = "--force" ] && FORCE=1

MODDIR=${0%/*}/..
LOG="$MODDIR/logs/unmigrate_${PKG}.log"
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT="/mnt/sdext4"

echo_log() { echo "[$(date '+%F %T')] $1" >> "$LOG"; echo "$1"; }
fail()     { echo_log "ERREUR: $1"; exit 1; }

[ -z "$PKG" ] && fail "Package requis. Usage: unmigrate_app.sh <package_name>"

mkdir -p "$MODDIR/logs"
echo ""                                                             >> "$LOG"
echo "========================================"                    >> "$LOG"
echo_log "unmigrate START: $PKG (force=$FORCE)"

SRC="/data/data/$PKG"
DST="$EXT4_MNT/app_data/$PKG"

# ---------------------------------------------------------------------------
# Étape 1 : Vérifications
# ---------------------------------------------------------------------------
grep -q "/data/data/$PKG$" "$CONF" 2>/dev/null || \
    fail "$PKG absent de bind_mounts.conf — non migré?"

[ -d "$DST" ] || fail "Répertoire ext4 absent: $DST"
[ -d "$SRC" ] || fail "Répertoire interne absent: $SRC"

# ---------------------------------------------------------------------------
# Étape 2 : Force-stop
# ---------------------------------------------------------------------------
echo_log "Force-stop $PKG..."
am force-stop "$PKG" 2>> "$LOG"
sleep 2

# ---------------------------------------------------------------------------
# Étape 3 : Resync ext4 → interne (avant umount)
# ---------------------------------------------------------------------------
# Le bind mount fait pointer SRC vers DST. Si on umount sans resync,
# l'app trouvera à SRC les données d'avant la migration (potentiellement stales).
# On doit d'abord umount temporairement pour accéder à SRC réel, resync, puis
# on peut laisser umount définitif.
#
# Mais umount avant resync = on perd le chemin vers ext4 via SRC.
# Solution : copier directement depuis DST vers SRC_REAL (via /proc/mounts).
# Avec le bind actif : SRC pointe vers DST. SRC réel est inaccessible via SRC.
# On lit depuis DST (ext4) et on écrit dans SRC_REAL après umount.
# ---------------------------------------------------------------------------
if [ $FORCE -eq 0 ]; then
    # Taille des données à resync
    EXT4_SIZE=$(du -sk "$DST" 2>/dev/null | awk '{print $1}')
    EXT4_SIZE=${EXT4_SIZE:-0}

    # Espace libre sur /data (stockage interne) — en excluant l'usage actuel de SRC
    # Avec le bind actif, df sur SRC mesure ext4. On mesure /data directement.
    DATA_FREE=$(df /data 2>/dev/null | tail -1 | awk '{print $4}')
    DATA_FREE=${DATA_FREE:-0}

    echo_log "Resync requis: ${EXT4_SIZE}KB | Libre /data: ${DATA_FREE}KB"

    # Marge sécurité : 5%
    NEEDED=$((EXT4_SIZE + EXT4_SIZE / 20 + 512))
    if [ "$NEEDED" -ge "$DATA_FREE" ]; then
        echo_log "ABORT: espace insuffisant pour resync sécurisé"
        echo_log "Requis: ${NEEDED}KB | Disponible: ${DATA_FREE}KB"
        echo_log "Options: libérer de l'espace ou utiliser --force (RISQUE perte données)"
        exit 2
    fi

    # Umount temporaire pour accéder au SRC réel
    echo_log "Umount temporaire du bind pour accéder au stockage interne..."
    umount "$SRC" 2>> "$LOG"
    UMOUNT_TMP_EC=$?
    echo_log "umount tmp exit=$UMOUNT_TMP_EC"
    [ $UMOUNT_TMP_EC -ne 0 ] && fail "Impossible de démonter bind pour resync"
    sleep 1

    # Resync DST (ext4) → SRC (interne) via tar pipe
    echo_log "Resync tar: $DST → $SRC..."
    (cd "$DST" && tar cf - . 2>> "$LOG" | tar xf - -C "$SRC" 2>> "$LOG")
    SYNC_EC=$?
    echo_log "resync tar exit=$SYNC_EC"

    if [ $SYNC_EC -ne 0 ]; then
        # Resync échoué : remonter le bind pour que l'app continue à fonctionner
        echo_log "Resync échoué — remontage bind (rollback)"
        mount --bind "$DST" "$SRC" 2>> "$LOG"
        fail "Resync échoué (code $SYNC_EC) — bind remis en place, données sécurisées"
    fi

    echo_log "Resync OK — ${EXT4_SIZE}KB synchronisés vers stockage interne"

    # Le bind est déjà démonté (umount tmp ci-dessus)
    BIND_ALREADY_UMOUNTED=1
else
    echo_log "FORCE mode — resync ignoré (risque perte données post-migration)"
    BIND_ALREADY_UMOUNTED=0
fi

# ---------------------------------------------------------------------------
# Étape 4 : Umount du bind (si pas déjà fait)
# ---------------------------------------------------------------------------
if [ "${BIND_ALREADY_UMOUNTED:-0}" = "0" ]; then
    echo_log "umount bind $SRC..."
    umount "$SRC" 2>> "$LOG"
    UMOUNT_EC=$?
    echo_log "umount exit=$UMOUNT_EC"
    [ $UMOUNT_EC -ne 0 ] && fail "umount échoué (code $UMOUNT_EC)"
fi

# ---------------------------------------------------------------------------
# Étape 5 : Retrait de bind_mounts.conf
# ---------------------------------------------------------------------------
grep -v "/data/data/$PKG$" "$CONF" > "${CONF}.tmp" && mv "${CONF}.tmp" "$CONF"
echo_log "Entrée retirée de bind_mounts.conf"

# Régénérer status.json
sh "$MODDIR/scripts/status.sh" > "$MODDIR/webroot/status.json" 2>/dev/null

echo_log "SUCCÈS: $PKG restauré sur stockage interne"
echo_log "Note: données ext4 conservées dans $DST (suppression manuelle possible)"
exit 0
