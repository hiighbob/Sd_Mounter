#!/system/bin/sh
# fix_exfat.sh — SD-Unfucker v1.8
# Wrapper WebUI : exécuté directement par index.html via ksu.exec()
# Charge les fonctions de service.sh et appelle fix_exfat()

MODDIR=${0%/*}/..
LOG="$MODDIR/logs/fix_exfat.log"
EXFAT_UUID="6603-7A19"
EXFAT_MNT="/storage/$EXFAT_UUID"
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT_FILE="$MODDIR/ext4_mountpoint.txt"
MMC_POWER="/sys/class/mmc_host/mmc1/power/control"
MMC_DELAY="/sys/class/mmc_host/mmc1/power/autosuspend_delay_ms"

mkdir -p "$MODDIR/logs"
echo "" >> "$LOG"
echo "========================================" >> "$LOG"
echo "[$(date '+%F %T')] fix_exfat.sh START v1.8" >> "$LOG"

log()    { echo "[$(date '+%F %T')] $1" | tee -a "$LOG"; }
log_ec() { echo "[$(date '+%F %T')]   exit=$1" >> "$LOG"; }

get_exfat_state() { sm list-volumes all 2>/dev/null | grep "$EXFAT_UUID" | awk '{print $2}'; }
get_exfat_volid() { sm list-volumes all 2>/dev/null | grep "$EXFAT_UUID" | awk '{print $1}'; }

_broadcast_mounted() {
    am broadcast -a android.intent.action.MEDIA_MOUNTED \
        --receiver-foreground --include-stopped-packages \
        -d "file://$EXFAT_MNT" >> "$LOG" 2>&1
}

_hotplug_simulate() {
    if [ -w "$MMC_POWER" ]; then
        [ -w "$MMC_DELAY" ] && echo 0 > "$MMC_DELAY" 2>/dev/null
        echo auto > "$MMC_POWER" 2>/dev/null; sleep 3
        echo on   > "$MMC_POWER" 2>/dev/null; sleep 5
        HWAIT=0
        while [ $HWAIT -lt 15 ]; do
            ST=$(get_exfat_state)
            echo "$ST" | grep -qiE "^mounted$|^checking$|^unmounted$" && break
            sleep 3; HWAIT=$((HWAIT+3))
        done
    else
        setprop ctl.restart vold >> "$LOG" 2>&1; sleep 10
    fi
}

# FIX #1: VOLID re-fetché en tête
EXFAT_VOLID=$(get_exfat_volid)
[ -z "$EXFAT_VOLID" ] && EXFAT_VOLID="public:179,33"
log "=== fix_exfat START (vol-id: $EXFAT_VOLID) ==="

if mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
    log "déjà monté — recover_grayed seulement"
    sh "$MODDIR/scripts/recover_grayed.sh" >> "$LOG" 2>&1
    log "SUCCÈS (déjà monté)"
    exit 0
fi

for fsck in /system/bin/fsck.exfat /system/xbin/fsck.exfat /sbin/fsck.exfat; do
    [ -x "$fsck" ] && { log "fsck.exfat -p"; "$fsck" -p /dev/block/mmcblk1p1 >> "$LOG" 2>&1; log_ec $?; sleep 2; break; }
done

log "sm mount $EXFAT_VOLID"
sm mount "$EXFAT_VOLID" >> "$LOG" 2>&1; log_ec $?
sleep 4

if echo "$(get_exfat_state)" | grep -qi "^mounted$"; then
    _broadcast_mounted
    sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
    log "SUCCÈS sm mount"; exit 0
fi

mkdir -p "$EXFAT_MNT"
OPTS="uid=1023,gid=1023,fmask=0007,dmask=0007,allow_utime=0022,utf8,quiet,errors=remount-ro"
mount -t sdfat /dev/block/mmcblk1p1 "$EXFAT_MNT" -o "$OPTS" >> "$LOG" 2>&1
if ! mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
    mount -t exfat /dev/block/mmcblk1p1 "$EXFAT_MNT" -o "$OPTS" >> "$LOG" 2>&1
fi
if mountpoint -q "$EXFAT_MNT" 2>/dev/null; then
    _broadcast_mounted
    sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
    log "SUCCÈS mount direct"; exit 0
fi

log "Mount direct échoué — HOTPLUG SIMULATION"
_hotplug_simulate
sleep 8
EXFAT_VOLID=$(get_exfat_volid)
[ -z "$EXFAT_VOLID" ] && EXFAT_VOLID="public:179,33"
sm mount "$EXFAT_VOLID" >> "$LOG" 2>&1
if echo "$(get_exfat_state)" | grep -qi "^mounted$"; then
    _broadcast_mounted
    sh "$MODDIR/scripts/recover_grayed.sh" --silent >> "$LOG" 2>&1
    log "SUCCÈS post-hotplug"; exit 0
fi

log "ECHEC total — retirer/réinsérer la carte SD manuellement"
exit 2
