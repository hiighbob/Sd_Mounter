#!/system/bin/sh
# status.sh — SD-Unfucker v1.6
MODDIR=${0%/*}/..
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT_FILE="$MODDIR/ext4_mountpoint.txt"
EXFAT_UUID="6603-7A19"

EXFAT_LINE=$(sm list-volumes all 2>/dev/null | grep "$EXFAT_UUID" | head -1)
EXFAT_ST=$(echo "$EXFAT_LINE" | awk '{print $2}')
EXFAT_VID=$(echo "$EXFAT_LINE" | awk '{print $1}')
[ -z "$EXFAT_ST" ]  && EXFAT_ST="unknown"
[ -z "$EXFAT_VID" ] && EXFAT_VID="public:179,33"

EXT4_MNT="/data/sdext2"
[ -f "$EXT4_MNT_FILE" ] && EXT4_MNT=$(cat "$EXT4_MNT_FILE" | tr -d '[:space:]')
EXT4_OK="false"
mountpoint -q "$EXT4_MNT" 2>/dev/null && EXT4_OK="true"

EXFAT_FREE=0; EXFAT_TOTAL=0
mountpoint -q "/storage/$EXFAT_UUID" 2>/dev/null && {
    EXFAT_FREE=$(df "/storage/$EXFAT_UUID" 2>/dev/null | tail -1 | awk '{print $4}')
    EXFAT_TOTAL=$(df "/storage/$EXFAT_UUID" 2>/dev/null | tail -1 | awk '{print $2}')
}

EXT4_FREE=0; EXT4_TOTAL=0
[ "$EXT4_OK" = "true" ] && {
    EXT4_FREE=$(df "$EXT4_MNT" 2>/dev/null | tail -1 | awk '{print $4}')
    EXT4_TOTAL=$(df "$EXT4_MNT" 2>/dev/null | tail -1 | awk '{print $2}')
}

INT_FREE=$(df /data 2>/dev/null | tail -1 | awk '{print $4}')
SELINUX="permissive"
[ -f /sys/fs/selinux/enforce ] && \
    [ "$(cat /sys/fs/selinux/enforce)" = "1" ] && SELINUX="enforcing"

BYTE450=$(dd if=/dev/block/mmcblk1 bs=1 skip=450 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
MMC_MHZ=$(cat /sys/kernel/debug/mmc1/clock 2>/dev/null | awk '{printf "%.0f",$1/1000000}')

BIND_COUNT=0; MIGRATED_JSON=""
[ -f "$CONF" ] && {
    BIND_COUNT=$(grep -c "mount --bind" "$CONF" 2>/dev/null || echo 0)
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        [ "${line#\#}" != "$line" ] && continue
        PKG=$(echo "$line" | awk '{print $4}' | sed 's|/data/data/||')
        DST=$(echo "$line" | awk '{print $3}')
        [ -z "$PKG" ] && continue
        SZ=0; [ -d "$DST" ] && SZ=$(du -sk "$DST" 2>/dev/null | awk '{print $1}')
        ACTIVE="false"; mountpoint -q "/data/data/$PKG" 2>/dev/null && ACTIVE="true"
        MIGRATED_JSON="${MIGRATED_JSON}{\"pkg\":\"$PKG\",\"size_kb\":${SZ:-0},\"bind_active\":$ACTIVE},"
    done < "$CONF"
    MIGRATED_JSON="${MIGRATED_JSON%,}"
}

cat << EOF
{
  "timestamp": "$(date '+%F %T')",
  "module_version": "v1.6",
  "selinux": "$SELINUX",
  "mbr_byte450": "0x${BYTE450:-??}",
  "mmc1_clock_mhz": ${MMC_MHZ:-0},
  "exfat": {
    "status": "$EXFAT_ST",
    "vol_id": "$EXFAT_VID",
    "uuid": "$EXFAT_UUID",
    "device": "mmcblk1p1",
    "free_kb": ${EXFAT_FREE:-0},
    "total_kb": ${EXFAT_TOTAL:-0}
  },
  "ext4": {
    "mounted": $EXT4_OK,
    "mountpoint": "$EXT4_MNT",
    "device": "mmcblk1p2",
    "free_kb": ${EXT4_FREE:-0},
    "total_kb": ${EXT4_TOTAL:-0}
  },
  "internal": { "free_kb": ${INT_FREE:-0} },
  "migrations": { "count": $BIND_COUNT, "packages": [$MIGRATED_JSON] }
}
EOF
