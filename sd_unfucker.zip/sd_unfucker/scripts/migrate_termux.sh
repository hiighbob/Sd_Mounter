#!/system/bin/sh
# migrate_termux.sh — SD-Unfucker v1.6
# Migration atomique groupe Termux (8 packages) vers /data/sdext2/data/

MODDIR=${0%/*}/..
LOG="$MODDIR/logs/migrate_termux.log"
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT_FILE="$MODDIR/ext4_mountpoint.txt"
TERMUX_PKGS="com.termux com.termux.api com.termux.boot com.termux.gui com.termux.styling com.termux.tasker com.termux.widget com.termux.window"

echo_log() { echo "[$(date '+%F %T')] $1" >> "$LOG"; echo "$1"; }
fail()     { echo_log "ERREUR: $1"; exit 1; }

mkdir -p "$MODDIR/logs"
echo "" >> "$LOG"
echo_log "=== migrate_termux START ==="

[ ! -d /data/data/com.termux ] && fail "com.termux non installé"

# Vérif aucun déjà migré
for PKG in $TERMUX_PKGS; do
    grep -q "/data/data/$PKG$" "$CONF" 2>/dev/null && fail "$PKG déjà dans conf"
done

# Trouver ext4
EXT4_MNT="/data/sdext2"
[ -f "$EXT4_MNT_FILE" ] && EXT4_MNT=$(cat "$EXT4_MNT_FILE" | tr -d '[:space:]')
mountpoint -q "$EXT4_MNT" 2>/dev/null || {
    ALT=$(grep "^/dev/block/mmcblk1p2 " /proc/mounts 2>/dev/null \
        | awk '{print $2}' | grep -v "^/data/app\|^/data/data" | head -1)
    [ -n "$ALT" ] && EXT4_MNT="$ALT" || fail "ext4 non montée"
}
echo_log "ext4: $EXT4_MNT"

# Espace
TOTAL=0
for PKG in $TERMUX_PKGS; do
    [ -d "/data/data/$PKG" ] || continue
    SZ=$(du -sk "/data/data/$PKG" 2>/dev/null | awk '{print $1}')
    TOTAL=$((TOTAL + ${SZ:-0}))
done
FREE=$(df "$EXT4_MNT" 2>/dev/null | tail -1 | awk '{print $4}')
NEEDED=$((TOTAL + TOTAL/10 + 102400))
echo_log "Total: ${TOTAL}KB | Libre: ${FREE}KB | Requis: ${NEEDED}KB"
[ -n "$FREE" ] && [ "$NEEDED" -ge "$FREE" ] && fail "Espace insuffisant"

# Force-stop tous
echo_log "Force-stop groupe Termux..."
for PKG in $TERMUX_PKGS; do am force-stop "$PKG" >> "$LOG" 2>&1; done
sleep 3

# Copie
COPIED=""
FAILED=0
for PKG in $TERMUX_PKGS; do
    [ -d "/data/data/$PKG" ] || { echo_log "SKIP (absent): $PKG"; continue; }
    DST="$EXT4_MNT/data/$PKG"
    mkdir -p "$DST"
    SRC_UID=$(stat -c "%u" "/data/data/$PKG" 2>/dev/null)
    SRC_GID=$(stat -c "%g" "/data/data/$PKG" 2>/dev/null)
    echo_log "tar: $PKG..."
    (cd "/data/data/$PKG" && tar cf - --ignore-failed-read . 2>>"$LOG") | \
        (cd "$DST" && tar xf - 2>>"$LOG")
    EC=$?
    echo_log "tar $PKG exit=$EC"
    if [ $EC -ne 0 ]; then FAILED=1; break; fi
    chown -R "$SRC_UID:$SRC_GID" "$DST" >> "$LOG" 2>&1
    COPIED="$COPIED $PKG"
done

# Rollback si échec
if [ $FAILED -eq 1 ]; then
    echo_log "Rollback..."
    for PKG in $COPIED; do rm -rf "$EXT4_MNT/data/$PKG" 2>/dev/null; done
    fail "Rollback effectué"
fi

# Activation simultanée des binds
BIND_OK=0; BIND_FAIL=0
for PKG in $COPIED; do
    DST="$EXT4_MNT/data/$PKG"
    echo "mount --bind $DST /data/data/$PKG" >> "$CONF"
    mount --bind "$DST" "/data/data/$PKG" >> "$LOG" 2>&1
    EC=$?
    echo_log "bind $PKG exit=$EC"
    [ $EC -eq 0 ] && BIND_OK=$((BIND_OK+1)) || BIND_FAIL=$((BIND_FAIL+1))
done

if [ $BIND_FAIL -gt 0 ]; then
    echo_log "WARN: $BIND_FAIL bind(s) échoués — rollback complet"
    for PKG in $COPIED; do
        umount "/data/data/$PKG" 2>/dev/null
        grep -v "/data/data/$PKG$" "$CONF" > "${CONF}.tmp" && mv "${CONF}.tmp" "$CONF"
        rm -rf "$EXT4_MNT/data/$PKG" 2>/dev/null
    done
    fail "Rollback bind mounts"
fi

sh "$MODDIR/scripts/status.sh" > "$MODDIR/webroot/status.json" 2>/dev/null
echo_log "SUCCÈS: $BIND_OK packages Termux migrés"
