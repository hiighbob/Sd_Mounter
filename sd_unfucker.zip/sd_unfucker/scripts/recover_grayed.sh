#!/system/bin/sh
# =============================================================================
# recover_grayed.sh — SD-Unfucker & Migrator v1.1
# =============================================================================
# RÔLE : Forcer PackageManager à rescanner les packages situés sur le volume
# exFAT après un montage réussi, pour réactiver les apps grisées sans reboot.
#
# MÉCANISME DES APPS GRISÉES :
#   Quand Android déplace une app via Paramètres → Appli → Stockage → Déplacer
#   vers la carte SD, l'APK est copié sur le volume exFAT. Au prochain boot,
#   si le volume n'est pas monté avant que PackageManager scanne les packages,
#   il marque l'app comme "unavailable" (grisée). Une fois le volume remonté,
#   PackageManager n'effectue PAS de rescan automatique — il faut lui signaler
#   explicitement que le volume est disponible.
#
# SOLUTION : broadcast MEDIA_MOUNTED + pm scan
#   - android.intent.action.MEDIA_MOUNTED : signal standard Android indiquant
#     qu'un volume vient d'être monté. PackageManager écoute ce broadcast et
#     rescanne le volume spécifié dans l'URI.
#   - --receiver-foreground : CRITIQUE sur Samsung Android 9. Sans ce flag,
#     le broadcast est mis en file d'attente et peut être traité plusieurs
#     minutes plus tard (ou jamais si le système est occupé). Avec ce flag,
#     le receiver dans PackageManager est exécuté immédiatement.
#   - pm scan : seconde passe pour les packages que MEDIA_MOUNTED seul n'a
#     pas rattachés (comportement observé sur Samsung One UI avec Magisk).
#   - Second broadcast : Samsung One UI ne met pas à jour les icônes du
#     launcher au premier signal. Un second broadcast espacé de 3s est
#     nécessaire pour que le launcher (com.sec.android.app.launcher) recharge
#     ses entrées depuis PackageManager.
#
# DEVICE     : SM-A530W · Android 9 · One UI
# VOLUME     : /storage/6603-7A19 (UUID exFAT)
# DÉPENDANCES: am, pm, sh (busybox Magisk)
# APPELÉ PAR : fix_exfat.sh (après montage réussi), service.sh (boot normal)
#              WebUI (index.html → runRecoverGrayed())
# GÉNÈRE     : webroot/recover_result.json (lu par WebUI)
#
# USAGE : recover_grayed.sh [--silent]
#   --silent : supprime la sortie stdout (pour appels depuis service.sh/fix_exfat.sh)
#
# CODES DE RETOUR :
#   0 → succès (toutes les apps récupérées)
#   1 → erreur (volume non monté)
#   2 → partiel (apps encore grisées après rescan)
#
# UPGRADE GUIDE :
#   - Pour un autre device : remplacer MOUNT_POINT par l'UUID de ta carte.
#   - Si pm scan n'est pas disponible (Android 10+) : supprimer cette étape,
#     le double broadcast seul devrait suffire.
#   - Le délai sleep 4 entre broadcast et pm scan est empirique pour ce device ;
#     sur un device plus rapide, 2s peut suffire.
# =============================================================================

MODDIR=${0%/*}/..
LOG="$MODDIR/logs/recover_grayed.log"
STATUS_FILE="$MODDIR/webroot/status.json"
RESULT_FILE="$MODDIR/webroot/recover_result.json"

SILENT=0
[ "$1" = "--silent" ] && SILENT=1

mkdir -p "$MODDIR/logs"
echo ""                                                          >> "$LOG"
echo "========================================"                 >> "$LOG"
echo "[$(date '+%F %T')] recover_grayed START"                 >> "$LOG"

echo_log() {
    echo "[$(date '+%F %T')] $1" >> "$LOG"
    [ $SILENT -eq 0 ] && echo "$1"
}

# -----------------------------------------------------------------------------
# Étape 1 : Vérifier que le volume est bien accessible
# -----------------------------------------------------------------------------
MOUNT_POINT="/storage/6603-7A19"
if ! mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    echo_log "ERREUR: $MOUNT_POINT non monté — abandon"
    exit 1
fi
echo_log "Volume confirmé monté : $MOUNT_POINT"

# -----------------------------------------------------------------------------
# Étape 2 : Baseline — nombre de packages visibles avant le rescan
# Permet de mesurer l'impact du broadcast dans le rapport final
# -----------------------------------------------------------------------------
PKG_BEFORE=$(pm list packages 2>/dev/null | wc -l)
echo_log "Packages avant broadcast: $PKG_BEFORE"

# -----------------------------------------------------------------------------
# Étape 3 : Premier broadcast MEDIA_MOUNTED
# --receiver-foreground : force exécution immédiate dans PackageManager
# -d file:// : URI du volume à scanner (doit correspondre exactement au path
#              de montage connu par StorageManager)
# -----------------------------------------------------------------------------
echo_log "Broadcast MEDIA_MOUNTED (1/2)..."
am broadcast \
    -a android.intent.action.MEDIA_MOUNTED \
    --receiver-foreground \
    -d "file://$MOUNT_POINT" \
    2>> "$LOG"
BC_EC=$?
echo_log "broadcast exit=$BC_EC"

# Laisser PackageManager traiter le broadcast avant pm scan
sleep 4

# -----------------------------------------------------------------------------
# Étape 4 : pm scan — seconde passe
# Certains packages sur Samsung Android 9 avec Magisk overlay ne sont pas
# redetectés par MEDIA_MOUNTED seul. pm scan force une relecture du répertoire.
# -----------------------------------------------------------------------------
echo_log "pm scan $MOUNT_POINT..."
pm scan "$MOUNT_POINT" 2>> "$LOG"
SCAN_EC=$?
echo_log "pm scan exit=$SCAN_EC"

sleep 3

# -----------------------------------------------------------------------------
# Étape 5 : Second broadcast MEDIA_MOUNTED
# Samsung One UI (com.sec.android.app.launcher) ne recharge ses icônes
# qu'après un second signal. Ce comportement est propre aux appareils Samsung
# Android 9 et n'est pas documenté dans l'AOSP.
# -----------------------------------------------------------------------------
echo_log "Broadcast MEDIA_MOUNTED (2/2 — Samsung One UI)..."
am broadcast \
    -a android.intent.action.MEDIA_MOUNTED \
    --receiver-foreground \
    -d "file://$MOUNT_POINT" \
    2>> "$LOG"
sleep 3

# -----------------------------------------------------------------------------
# Étape 6 : Mesure du résultat
# -----------------------------------------------------------------------------
PKG_AFTER=$(pm list packages 2>/dev/null | wc -l)
PKG_RECOVERED=$((PKG_AFTER - PKG_BEFORE))
echo_log "Packages après: $PKG_AFTER (delta: +$PKG_RECOVERED)"

# -----------------------------------------------------------------------------
# Étape 7 : Identifier les packages encore désactivés sur le volume
# pm list packages -d retourne uniquement les packages disabled/unavailable
# On filtre ceux dont le chemin APK est sur le volume exFAT
# -----------------------------------------------------------------------------
STILL_DISABLED=""
DISABLED_COUNT=0
while IFS= read -r line; do
    PKG=$(echo "$line" | sed 's/package://')
    [ -z "$PKG" ] && continue
    APK_PATH=$(pm path "$PKG" 2>/dev/null | sed 's/package://')
    if echo "$APK_PATH" | grep -q "$MOUNT_POINT"; then
        STILL_DISABLED="$STILL_DISABLED $PKG"
        DISABLED_COUNT=$((DISABLED_COUNT + 1))
        echo_log "  Toujours désactivé: $PKG"
    fi
done << DISABLED_LIST
$(pm list packages -d 2>/dev/null)
DISABLED_LIST

echo_log "Apps toujours grisées: $DISABLED_COUNT"

# -----------------------------------------------------------------------------
# Étape 8 : Écriture de recover_result.json
# Consommé par le WebUI (index.html → loadRecoverResult())
# Le JSON est généré manuellement pour éviter une dépendance à jq ou python
# -----------------------------------------------------------------------------
DISABLED_JSON=""
for PKG in $STILL_DISABLED; do
    DISABLED_JSON="${DISABLED_JSON}\"${PKG}\","
done
DISABLED_JSON="${DISABLED_JSON%,}"  # Retirer la virgule finale

cat > "$RESULT_FILE" << JSONEOF
{
  "timestamp": "$(date '+%F %T')",
  "mount_point": "$MOUNT_POINT",
  "pkg_before": $PKG_BEFORE,
  "pkg_after": $PKG_AFTER,
  "pkg_recovered": $PKG_RECOVERED,
  "still_disabled_count": $DISABLED_COUNT,
  "still_disabled": [$DISABLED_JSON],
  "broadcast_exit": $BC_EC,
  "scan_exit": $SCAN_EC
}
JSONEOF

echo_log "recover_result.json écrit"
sh "$MODDIR/scripts/status.sh" > "$STATUS_FILE" 2>/dev/null

if [ $DISABLED_COUNT -eq 0 ]; then
    echo_log "SUCCÈS: toutes les apps récupérées"
    exit 0
else
    echo_log "PARTIEL: $DISABLED_COUNT app(s) encore grisée(s)"
    exit 2
fi
