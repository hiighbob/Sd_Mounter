#!/system/bin/sh
# migrate_app.sh — SD-Unfucker v1.6
# Déplace une app de /data/data/<pkg> vers /data/sdext2/data/<pkg>
# Usage : migrate_app.sh <package_name>

PKG="$1"
MODDIR=${0%/*}/..
LOG="$MODDIR/logs/migrate_${PKG}.log"
CONF="$MODDIR/bind_mounts.conf"
EXT4_MNT_FILE="$MODDIR/ext4_mountpoint.txt"

echo_log() { echo "[$(date '+%F %T')] $1" >> "$LOG"; echo "$1"; }
fail()     { echo_log "ERREUR: $1"; exit 1; }

[ -z "$PKG" ] && fail "Usage: migrate_app.sh <package_name>"
[ "$PKG" = "com.termux" ] && {
    echo_log "→ Redirection migrate_termux.sh"
    sh "$MODDIR/scripts/migrate_termux.sh"; exit $?
}

SRC="/data/data/$PKG"
[ ! -d "$SRC" ] && fail "$SRC introuvable"
grep -q "/data/data/$PKG$" "$CONF" 2>/dev/null && fail "$PKG déjà migré"

mkdir -p "$MODDIR/logs"
echo "" >> "$LOG"
echo_log "=== Migration $PKG ==="

# Trouver mountpoint ext4
EXT4_MNT="/data/sdext2"
[ -f "$EXT4_MNT_FILE" ] && EXT4_MNT=$(cat "$EXT4_MNT_FILE" | tr -d '[:space:]')
mountpoint -q "$EXT4_MNT" 2>/dev/null || {
    ALT=$(grep "^/dev/block/mmcblk1p2 " /proc/mounts 2>/dev/null \
        | awk '{print $2}' | grep -v "^/data/app\|^/data/data" | head -1)
    [ -n "$ALT" ] && EXT4_MNT="$ALT" || fail "ext4 non montée"
}
echo_log "ext4 mountpoint: $EXT4_MNT"

DST="$EXT4_MNT/data/$PKG"
mkdir -p "$DST"

SRC_UID=$(stat -c "%u" "$SRC" 2>/dev/null)
SRC_GID=$(stat -c "%g" "$SRC" 2>/dev/null)
SRC_SIZE=$(du -sk "$SRC" 2>/dev/null | awk '{print $1}')
DST_FREE=$(df "$EXT4_MNT" 2>/dev/null | tail -1 | awk '{print $4}')
echo_log "Taille: ${SRC_SIZE}KB | Libre: ${DST_FREE}KB | UID=$SRC_UID GID=$SRC_GID"

[ -n "$SRC_SIZE" ] && [ -n "$DST_FREE" ] && [ "$SRC_SIZE" -ge "$DST_FREE" ] && \
    fail "Espace insuffisant (${SRC_SIZE}KB requis, ${DST_FREE}KB dispo)"

echo_log "Force-stop $PKG..."
am force-stop "$PKG" >> "$LOG" 2>&1
sleep 2

echo_log "tar pipeline $SRC → $DST..."
(cd "$SRC" && tar cf - --ignore-failed-read . 2>>"$LOG") | \
    (cd "$DST" && tar xf - 2>>"$LOG")
TAR_EC=$?
echo_log "tar exit=$TAR_EC"
[ $TAR_EC -ne 0 ] && fail "Copie tar échouée"

chown -R "$SRC_UID:$SRC_GID" "$DST" >> "$LOG" 2>&1

echo "mount --bind $DST $SRC" >> "$CONF"
mount --bind "$DST" "$SRC" >> "$LOG" 2>&1
BIND_EC=$?
echo_log "bind exit=$BIND_EC"

if [ $BIND_EC -ne 0 ]; then
    grep -v "/data/data/$PKG$" "$CONF" > "${CONF}.tmp" && mv "${CONF}.tmp" "$CONF"
    fail "bind mount échoué — rollback conf"
fi

sh "$MODDIR/scripts/status.sh" > "$MODDIR/webroot/status.json" 2>/dev/null
echo_log "SUCCÈS: $PKG migré vers $DST"
