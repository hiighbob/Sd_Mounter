#!/system/bin/sh
# post-fs-data.sh — SD-Unfucker v1.8
MODDIR=${0%/*}
LOG="$MODDIR/logs/post-fs-data.log"
CONF="$MODDIR/bind_mounts.conf"

mkdir -p "$MODDIR/logs"
echo "" >> "$LOG"
echo "========================================" >> "$LOG"
echo "[$(date '+%F %T')] post-fs-data START v1.8" >> "$LOG"

EXT4_MNT=$(grep "^/dev/block/mmcblk1p2 " /proc/mounts 2>/dev/null \
    | awk '{print $2}' | grep -v "^/data/app\|^/data/data" | head -1)

if [ -z "$EXT4_MNT" ]; then
    echo "[$(date '+%F %T')] mmcblk1p2 absente — service.sh prendra le relais" >> "$LOG"
    exit 0
fi

echo "[$(date '+%F %T')] mmcblk1p2 mountpoint: $EXT4_MNT" >> "$LOG"

# CORE FIX: remount avec exec,suid,dev pour Termux et binaires ext4
mount -o remount,exec,suid,dev "$EXT4_MNT" >> "$LOG" 2>&1
echo "[$(date '+%F %T')] ext4 remounted exec,suid,dev exit=$?" >> "$LOG"
echo "$EXT4_MNT" > "$MODDIR/ext4_mountpoint.txt"

EXT4_DATA="$EXT4_MNT/data"
[ ! -d "$EXT4_DATA" ] && exit 0

# Auto-génération bind_mounts.conf si vide
CONF_ENTRIES=$(grep -c "mount --bind" "$CONF" 2>/dev/null || echo 0)
if [ "$CONF_ENTRIES" -eq 0 ]; then
    {
        echo "# SD-Unfucker bind_mounts.conf — auto-généré $(date '+%F %T')"
        for pkgdir in "$EXT4_DATA"/*/; do
            PKG=$(basename "$pkgdir")
            [ "$PKG" = "*" ] && continue
            echo "mount --bind $pkgdir /data/data/$PKG"
        done
    } > "$CONF"
    CONF_ENTRIES=$(grep -c "mount --bind" "$CONF" 2>/dev/null || echo 0)
    echo "[$(date '+%F %T')] $CONF_ENTRIES entrées auto-générées" >> "$LOG"
fi

# Rejouer bind mounts — avec compteurs (restaurés v1.8)
OK=0; SKIP=0; FAIL=0; ALREADY=0
while IFS= read -r line; do
    [ -z "$line" ] && continue
    case "$line" in '#'*) continue ;; esac
    SRC=$(echo "$line" | awk '{print $3}')
    DST=$(echo "$line" | awk '{print $4}')
    # FIX #2: deux conditions séparées
    [ -z "$SRC" ] && continue
    [ -z "$DST" ] && continue

    if mountpoint -q "$DST" 2>/dev/null; then
        ALREADY=$((ALREADY+1))
        continue
    fi
    if [ -d "$SRC" ] && [ -d "$DST" ]; then
        mount --bind "$SRC" "$DST" >> "$LOG" 2>&1
        EC=$?
        echo "[$(date '+%F %T')] bind exit=$EC : $SRC → $DST" >> "$LOG"
        [ $EC -eq 0 ] && OK=$((OK+1)) || FAIL=$((FAIL+1))
    else
        echo "[$(date '+%F %T')] SKIP: src=$([ -d "$SRC" ] && echo Y || echo N) dst=$([ -d "$DST" ] && echo Y || echo N)" >> "$LOG"
        SKIP=$((SKIP+1))
    fi
done < "$CONF"

echo "[$(date '+%F %T')] binds: OK=$OK SKIP=$SKIP FAIL=$FAIL ALREADY=$ALREADY" >> "$LOG"
echo "[$(date '+%F %T')] post-fs-data END v1.8" >> "$LOG"
