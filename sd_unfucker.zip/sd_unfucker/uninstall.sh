#!/system/bin/sh
# =============================================================================
# uninstall.sh — SD-Unfucker & Migrator v1.3
# =============================================================================
#
# RÔLE : Nettoyage à la désinstallation du module via Magisk Manager.
#   Exécuté par Magisk AVANT suppression du répertoire du module.
#
# ⚠️  AVERTISSEMENT : Ce script démontre les bind mounts SANS resync des
#   données ext4 → interne. Les apps retrouveront leur stockage interne
#   dans l'état d'avant migration (données post-migration sur ext4 inaccessibles).
#   Pour une désinstallation propre avec préservation des données :
#   1. Utiliser "Annuler migration" dans le WebUI pour chaque app (unmigrate_app.sh)
#   2. Puis désinstaller le module
#
# SÉQUENCE :
#   1. Démonter tous les bind mounts depuis bind_mounts.conf
#   2. Démonter la partition ext4 (/mnt/sdext4)
#   3. Logguer le résultat
#
# Note : on ne supprime PAS les données sur ext4 — elles restent accessibles
# depuis un gestionnaire de fichiers root si nécessaire.
# =============================================================================

MODDIR=${0%/*}
LOG="/data/local/tmp/sd_unfucker_uninstall.log"
CONF="$MODDIR/bind_mounts.conf"

echo "[$(date '+%F %T')] uninstall.sh START" > "$LOG"

# Démonter les bind mounts actifs
UMOUNT_OK=0; UMOUNT_FAIL=0
if [ -f "$CONF" ]; then
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        [ "${line#\#}" != "$line" ] && continue
        DST=$(echo "$line" | awk '{print $4}')
        if [ -n "$DST" ]; then
            umount "$DST" 2>> "$LOG"
            EC=$?
            echo "[$(date '+%F %T')] umount $DST exit=$EC" >> "$LOG"
            [ $EC -eq 0 ] && UMOUNT_OK=$((UMOUNT_OK+1)) || UMOUNT_FAIL=$((UMOUNT_FAIL+1))
        fi
    done < "$CONF"
fi
echo "[$(date '+%F %T')] bind umount: OK=$UMOUNT_OK FAIL=$UMOUNT_FAIL" >> "$LOG"

# Démonter ext4
if mountpoint -q /mnt/sdext4 2>/dev/null; then
    umount /mnt/sdext4 2>> "$LOG"
    echo "[$(date '+%F %T')] ext4 umount exit=$?" >> "$LOG"
fi

echo "[$(date '+%F %T')] uninstall.sh END" >> "$LOG"
# Le log est dans /data/local/tmp car le répertoire du module sera supprimé
